﻿using System;
class Program
{
    static void Main()
    {
        long bundle1 = long.Parse(Console.ReadLine());
        long bundle2 = long.Parse(Console.ReadLine());
        long bundle3 = long.Parse(Console.ReadLine());
        long bundle4 = long.Parse(Console.ReadLine());
        long tableTops = long.Parse(Console.ReadLine());
        long tablesNeeded = long.Parse(Console.ReadLine());

        long totalLegs = 1 * bundle1 + 2 * bundle2 + 3 * bundle3 + 4 * bundle4;
        long legsNeeded = tablesNeeded * 4;
        long topsNeeded = tablesNeeded;

        long topsLeft = tableTops - topsNeeded;
        long legsLeft = totalLegs - legsNeeded;
        long tablesLeft = Math.Min(topsLeft, legsLeft / 4);
        if (legsLeft % 4 < 0)
        {
            tablesLeft--;
        }

        if (topsLeft == 0 && legsLeft >= 0)
        {
            Console.WriteLine("Just enough tables made: {0}", tablesNeeded);
        }

        if (topsLeft > 0 && legsLeft >= 0)
        {
            Console.WriteLine("more: {0}", tablesLeft);
            Console.WriteLine("tops left: {0}, legs left: {1}", topsLeft, legsLeft);
        }

        if (topsLeft < 0 || legsLeft < 0)
        {
            Console.WriteLine("less: {0}", tablesLeft);
            Console.WriteLine("tops needed: {0}, legs needed: {1}",
                Math.Max(-topsLeft, 0),
                Math.Max(-legsLeft, 0));
        }

    }
}