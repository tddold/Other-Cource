﻿using System;

class MultipleElseToSwitch
{
    static void Main()
    {
        Console.Write("Please enter a character: ");
        char ch = (char)Console.Read();

        switch (ch)
        {
            case 'A':
            case 'a':
                Console.WriteLine("Vowel [ei]");
                break;
            case 'E':
            case 'e':
                Console.WriteLine("Vowel [i:]");
                break;
            case 'I':
            case 'i':
                Console.WriteLine("Vowel [ai]");
                break;
            case 'O':
            case 'o':
                Console.WriteLine("Vowel [ou]");
                break;
            case 'U':
            case 'u':
                Console.WriteLine("Vowel [ju:]");
                break;
            default:
                Console.WriteLine("Consonant");
                break;
        }
    }
}
